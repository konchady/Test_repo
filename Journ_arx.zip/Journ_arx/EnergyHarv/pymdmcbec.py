import numpy as np
from scipy.stats import norm as nr
from matplotlib import pyplot as plt
from time import time as tim


# L(0) = 0; L(1) = 3

def pyent(p):
    if p == 0 or p == 1:
        return 0
    else:
        return -p*np.log2(p) - (1 - p)*np.log2(1 - p)


def pykel(err, ebar, sbar2, lam):
    return np.sqrt(4*(3*ebar - ebar**2 + sbar2)/((1 - lam)*err*(ebar**2)))


def pyratelb_bec(n, err, ebar, sbar2, alpha, lam, p0):
    C_bec = (1-alpha)*pyent(p0)
    V_bec = (1-alpha)*p0*(np.log2(p0))**2 + (1-alpha)*(1-p0)*(np.log2(1-p0))**2 - C_bec**2
    return C_bec - (pykel(err, ebar, sbar2, lam)*C_bec - np.sqrt(V_bec)*nr.ppf(lam*err))/np.sqrt(n) - np.log2(n)/(2*n)


def pyrateub_bec(n, err, ebar, sbar2, alpha, p0):
    C_bec = (1 - alpha) * pyent(p0)
    V_bec = (1-alpha)*p0*(np.log2(p0))**2 + (1-alpha)*(1-p0)*(np.log2(1-p0))**2 - C_bec**2
    D_e = np.sqrt(4*sbar2/err)
    C_pr = (1-alpha)*np.log2((1-p0)/p0)
    return C_bec + D_e*C_pr/np.sqrt(n) + np.sqrt(V_bec/n)*nr.ppf(err*1.25) + np.log2(n)/n


err = 0.1
n = np.arange(5000, 10001, 500)
ebar = 1
sigbar_2 = 0.16
alpha = 0.05
p0 = 2/3

stt = tim()
Mlb = np.zeros(len(n), dtype=float)
Mub = np.zeros(len(n), dtype=float)
kep = np.zeros(len(n), dtype=float)
nhat = np.zeros(len(n), dtype=float)
for i, ni in enumerate(n):
    lmax = 0
    Mmax = 0
    lam = np.arange(0.05, 0.96, 0.01)
    for l in lam:
        Mt = pyratelb_bec(ni, err, ebar, sigbar_2, alpha, l, p0)
        if Mt > Mmax:
            lmax = l
            Mmax = Mt
    Mlb[i] = Mmax
    kep[i] = pykel(err, ebar, sigbar_2, lmax)
    Mub[i] = pyrateub_bec(ni, err, ebar, sigbar_2, alpha, p0)
    nhat[i] = kep[i]*(np.sqrt(kep[i]**2 + 4*ni) - kep[i])/2

nz = zip(n, nhat)
for it in nz:
    print(it)

ett = tim()

plt.figure(1)
plt.subplot(121)
plt.plot(n, Mlb)
plt.plot(n, Mub, 'r')
plt.plot(n, np.ones(len(n))*((1-alpha)*pyent(p0)), 'b--')
plt.xlabel('Blocklength n')
plt.ylabel('Rate in bits per channel use')
# plt.title('Finite Blocklength rates for EH-AWGN channel')
plt.legend(['Lower Bound on Rate', 'Upper bound on Rate', 'Channel Capacity'])
plt.grid(True)
plt.axis([5000, 10000, 0.5, 0.9])

# plt.show()
# plt.figure(2)
plt.subplot(122)
plt.plot(n, nhat, 'b')
plt.xlabel('Blocklength n')
plt.ylabel('Slots for harvesting energy')
# plt.axis([5000, 10000, 600, 950])
plt.grid(True)
# plt.subplots_adjust(hspace=1)
plt.show()

print('This program took ', ett-stt, ' seconds.')
