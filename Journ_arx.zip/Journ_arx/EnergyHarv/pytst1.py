import numpy as np
# import matplotlib.pyplot as plt

a = [1, 2]
b = [5, 6]
c = sum(sum(x*y for x in [1, 2]) for y in [5, 6])
print(c)
print(4*3**2)
