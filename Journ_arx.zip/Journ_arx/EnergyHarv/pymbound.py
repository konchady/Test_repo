import numpy as np
from scipy.stats import norm as nr
from matplotlib import pyplot as plt
from time import time as tim


def pykel(err, ebar, sbar2, lam):
    return np.sqrt(4*(2*(ebar**2) + sbar2)/((1 - lam)*err*(ebar**2)))


def pyratelb(n, err, ebar, sbar2, sn2, lam):
    c_eg = 0.5*np.log2(1 + ebar/sn2)
    v_eg1 = ebar/(ebar + sn2)*(np.log2(np.e)**2)
    kel = np.sqrt(4*(2*(ebar**2) + sbar2)/((1 - lam)*err*(ebar**2)))
    return c_eg + (np.sqrt(v_eg1)*nr.ppf(lam*err) - kel*c_eg)/np.sqrt(n) - 0.5*np.log2(n)/n


def pyrateub(n, err, ebar, sbar2, sn2):
    c_eg = 0.5*np.log2(1 + ebar/sn2)
    v_eg2 = (2*ebar**2 + sbar2 + 4*sn2*ebar)/(4*(ebar + sn2)**2)*(np.log2(np.e))**2
    return c_eg + np.sqrt(v_eg2/n)*nr.ppf(err) + 0.5*np.log2(n)/n


err = 0.1
n = np.arange(5000, 10001, 500)
ebar = 1
sigbar_2 = 0.16
sig_n2 = 0.01

stt = tim()
Mlb = np.zeros(len(n), dtype=float)
Mub = np.zeros(len(n), dtype=float)
kep = np.zeros(len(n), dtype=float)
nhat = np.zeros(len(n), dtype=float)
for i, ni in enumerate(n):
    lmax = 0
    Mmax = 0
    lam = np.arange(0.05, 0.96, 0.01)
    for l in lam:
        Mt = pyratelb(ni, err, ebar, sigbar_2, sig_n2, l)
        if Mt > Mmax:
            lmax = l
            Mmax = Mt
    Mlb[i] = Mmax
    kep[i] = pykel(err, ebar, sigbar_2, lmax)
    Mub[i] = pyrateub(ni, err, ebar, sigbar_2, sig_n2)
    nhat[i] = kep[i]*(np.sqrt(kep[i]**2 + 4*ni) - kep[i])/2

nz = zip(n, nhat)
for it in nz:
    print(it)

ett = tim()

plt.figure(1)
plt.subplot(121)
plt.plot(n, Mlb)
plt.plot(n, Mub, 'r')
plt.plot(n, np.ones(len(n))*0.5*np.log2(1 + ebar/sig_n2), 'b--')
plt.xlabel('Blocklength n')
plt.ylabel('Rate in bits per channel use')
# plt.title('Finite Blocklength rates for EH-AWGN channel')
plt.legend(['Lower Bound on Rate', 'Upper bound on Rate', 'Channel Capacity'])
plt.grid(True)
plt.axis([5000, 10000, 0, 4])

# plt.show()
# plt.figure(2)
plt.subplot(122)
plt.plot(n, nhat, 'b')
plt.xlabel('Blocklength n')
plt.ylabel('Slots for harvesting energy')
plt.axis([5000, 10000, 600, 950])
plt.grid(True)
# plt.subplots_adjust(hspace=1)
plt.show()

print('This program took ', ett-stt, ' seconds.')
